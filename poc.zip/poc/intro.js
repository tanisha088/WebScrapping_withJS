// // variable declare 
// let a;
// console.log(a);
// // primitve types : number string undefined boolean null symbol
// a = 1;
// console.log(a);
// a = null;
// a = true;
// console.log(a);
// let number = 10;
// for (let i = 1; i <= 10; i++) {
//     console.log("Number is ", i);
// }