// nodejs
let libObj = require("./lib");
console.log("I am code file");
console.log(libObj)
// object -> undefined
console.log(libObj.a);
console.log(libObj.varname);
libObj.fnFunction("Hello");
